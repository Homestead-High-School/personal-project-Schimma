Apply this patch to a .gba rom of Pokémon FireRed 1.0 (USA) with Lunar IPS or an equivalent program

The hack has been tested on Visual Boy Advance and has also been run on Everdrive X5 Mini and EZ-Flash Omega

Version 1.0
-Samus as the female trainer
-Metroid starter over Bulbasaur
-Mother Brain Over Mewtwo

Version 2.0
-Ridley starter over Charmander
-X starter over Squirtle
-Rebalanced Metroid and Mother Brain

Version 3.0
-Kraid, Draygon and Phantoon added as legendaries
-Starters now catchable in the wild
-Rival changed to Dark Samus with new teams

Hope you enjoy it

This is as far as I'm able to take this project by myself. If you'd like to contribute to further versions of this hack featuring more changes feel free to contact me via twitter DM @GuilhermeRM_art 