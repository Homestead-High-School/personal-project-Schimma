BACKGROUND:

     This is a POKEMON - Fire Red hack created by LocksmithArmy for the VIZZED.COM board community. It is my entry into the "POKEMON ROM HACKING COMPETITION" being held on the board. 
UPDATE: 
     This hack won the competition and prospered for several years. Nintendo contacted the Vizzed leadership and had them remove all Nintendo intellectual property, this included this hack.
Now this hack is free to distribute off VIZZED>COM as long as it is unaltered in any way.

STORY:

     After your grueling defeat at SILPH CO. your boss, GIOVANNI, calls you (and all the other scientists that were fired after that failure) in for a meeting at his gym in VIRIDIAN CITY. You are all put under new management and given the task of creating more powerful POKEMON.
     While most of your team is in a lab actually creating these "powerful POKEMON" you are tasked with field work. Your new job is to run missions, test experiments and help TEAM ROCKET succeed in their mission.
     You may be loaned out to help with other TEAM ROCKET missions. You may get to test out these "powerful POKEMON" before GIOVANNI gets his hands on them. You will definitely see the damage caused to TEAM ROCKET by a certain young hero.
     See KANTO from a whole new perspective. Enjoy the dark side.

INSTRUCTIONS:

     For to patch this IPS file you only need the contents of this .rar file and your origional copy of Pokemon - Fire Red Version (USA) 1.0.

     Unzip this .rar archive (I use WinRAR) to any location on your computer.
     Add your Pokemon Fire Red Version rom to that folder.
     Double click the "Lunar IPS.exe" application
     Once it is opened click "Apply IPS Patch"
     Then select the "Pokemon - Rocket Science (LSA).ips" file
     Next you will be prompted to select your clean copy of Pokemon Fire Red Version... 
     After you select your rom the patch will be applied... you may want to rename your patched rom.

Have fun!